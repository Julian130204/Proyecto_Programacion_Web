<?php
include_once '../bd/conexion.php';
$objeto = new Conexion();
$conexion = $objeto->Conectar();
// Recepción de los datos enviados mediante POST desde el JS   

$id =           (isset($_POST['id']))           ? $_POST['id'] : '';
$actividad =    (isset($_POST['actividad']))    ? $_POST['actividad'] : '';
$descripcion =  (isset($_POST['descripcion']))  ? $_POST['descripcion'] : '';
$horario =      (isset($_POST['horario']))      ? $_POST['horario'] : '';
$fechainicio =  (isset($_POST['fechainicio']))  ? $_POST['fechainicio'] : '';
$fechafin =     (isset($_POST['fechafin']))     ? $_POST['fechafin'] : '';

switch($opcion){
    case 1: //alta
        $consulta = "INSERT INTO actividades (actividad, descripcion, horario, fechainicio, fechafin) VALUES('$actividad', '$descripcion', '$horario', '$fechainicio', '$fechafin' ) ";			
        $resultado = $conexion->prepare($consulta);
        $resultado->execute(); 

        $consulta = "SELECT id, actividad, descripcion, horario, fechainicio, fechafin FROM actividades ORDER BY id DESC LIMIT 1";
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();
        $data=$resultado->fetchAll(PDO::FETCH_ASSOC);
        break;
    case 2: //modificación
        $consulta = "UPDATE actividades SET actividad='$actividad', descripcion='$descripcion', horario='$horario', fechainicio='$fechainicio', fechafin='$fechafin' WHERE id='$id' ";		
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();        
        
        $consulta = "SELECT id, actividad, descripcion, horario, fechainicio, fechafin FROM actividades WHERE id='$id' ";       
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();
        $data=$resultado->fetchAll(PDO::FETCH_ASSOC);
        break;        
    case 3://baja
        $consulta = "DELETE FROM actividades WHERE id='$id' ";		
        $resultado = $conexion->prepare($consulta);
        $resultado->execute();                           
        break;        
}

print json_encode($data, JSON_UNESCAPED_UNICODE); //enviar el array final en formato json a JS
$conexion = NULL;
