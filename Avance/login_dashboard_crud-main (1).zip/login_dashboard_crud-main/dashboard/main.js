$(document).ready(function(){
    tablaActividades = $("#tablaActividades").DataTable({
    "columnDefs": [{
    "targets": -1,
    "data": null,
    "defaultContent": "<div class='text-center'><div class='btn-group'><button class='btn btn-primary btnEditar'>Editar</button><button class='btn btn-danger btnBorrar'>Borrar</button></div></div>"
}],

        
    "language": {
            "lengthMenu": "Mostrar _MENU_ registros",
            "zeroRecords": "No se encontraron resultados",
            "info": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
            "infoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
            "infoFiltered": "(filtrado de un total de _MAX_ registros)",
            "sSearch": "Buscar:",
            "oPaginate": {
                "sFirst": "Primero",
                "sLast":"Último",
                "sNext":"Siguiente",
                "sPrevious": "Anterior"
            },
            "sProcessing":"Procesando..."
        }
    });
    
$("#btnNuevo").click(function(){
    $("#formActividades").trigger("reset");
    $(".modal-header").css("background-color", "#1cc88a");
    $(".modal-header").css("color", "white");
    $(".modal-title").text("Nueva Actividad");            
    $("#modalCRUD").modal("show");        
    id=null;
    opcion = 1; //alta
});    
    
var fila; //capturar la fila para editar o borrar el registro
    
//botón EDITAR    
$(document).on("click", ".btnEditar", function(){
    fila = $(this).closest("tr");
    id = parseInt(fila.find('td:eq(0)').text());
    actividad = (fila.find('td:eq(1)').text());
    descripcion = (fila.find('td:eq(2)').text());
    horario = (fila.find('td:eq(3)').text());
    fechainicio = (fila.find('td:eq(4)').text());
    fechafin = (fila.find('td:eq(5)').text());
    
    $("#actividad").val(actividad);
    $("#descripcion").val(descripcion);
    $("#horario").val(horario);
    $("#fechainicio").val(fechainicio);
    $("#fechafin").val(fechafin);
    opcion = 2; //editar
    
    $(".modal-header").css("background-color", "#4e73df");
    $(".modal-header").css("color", "white");
    $(".modal-title").text("Editar Actividad");            
    $("#modalCRUD").modal("show");  
    
});

//botón BORRAR
$(document).on("click", ".btnBorrar", function(){    
    fila = $(this);
    actividad = parseInt($(this).closest("tr").find('td:eq(1)').text());
    opcion = 3 //borrar
    var respuesta = confirm("¿Está seguro de eliminar el registro: "+actividad+"?");
    if(respuesta){
        $.ajax({
            url: "bd/crud.php",
            type: "POST",
            dataType: "json",
            data: {opcion:opcion, actividad:actividad},
            success: function(){
                tablaActividades.row(fila.parents('tr')).remove().draw();
            }
        });
    }   
});
    
$("#formActividades").submit(function(e){
    e.preventDefault();
    id = $.trim($("#id").val());
    actividad = $.trim($("#actividad").val());
    descripcion = $.trim($("#descripcion").val());
    horario = $.trim($("#horario").val());    
    fechainicio = $.trim($("#fechainicio").val());  
    fechafin = $.trim($("#fechafin").val());  
    $.ajax({
        url: "bd/crud.php",
        type: "POST",
        dataType: "json",
        data: {id:id, actividad:actividad, descripcion:descripcion, horario:horario, fechainicio:fechainicio, fechafin:fechafin},
        success: function(data){  
            console.log(data);
            id = data[0].id;
            actividad = data[0].actividad;            
            descripcion = data[0].descripcion;
            horario = data[0].horario;
            fechainicio = data[0].fechainicio;
            fechafin = data[0].fechafin;
            if(opcion == 1){tablaActividades.row.add([id,actividad,descripcion,horario,fechainicio,fechafin]).draw();}
            else{tablaActividades.row(fila).data([id,actividad,descripcion,horario,fechainicio,fechafin]).draw();}            
        }        
    });
    $("#modalCRUD").modal("show");    
    
});    
    
});